npm install // Установка зависимостей
npx babel filejsx --out-file file.js - перевоыд в js

node app.js - запуск сервера